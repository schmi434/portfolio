package com.techelevator.model;

public class Food {
	
	private int calories;
	
	private int carbs;
	
	private int protein;
	
	private int fat;
	

	public int getCalories() {
		return calories;
	}

	public int getCarbs() {
		return carbs;
	}

	public int getProtein() {
		return protein;
	}

	public int getFat() {
		return fat;
	}

	public void setCalories(int calories) {
		this.calories = calories;
	}

	public void setCarbs(int carbs) {
		this.carbs = carbs;
	}

	public void setProtein(int protein) {
		this.protein = protein;
	}

	public void setFat(int fat) {
		this.fat = fat;
	}
	
	

}
